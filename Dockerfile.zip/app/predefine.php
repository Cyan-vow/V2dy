<?php

declare(strict_types=1);
/**
 * To define global variable
 */

define('BASE_PATH', __DIR__ . '/..');
define('VERSION', '20180419');
