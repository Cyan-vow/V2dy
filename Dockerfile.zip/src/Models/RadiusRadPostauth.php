<?php

namespace App\Models;

class RadiusRadPostauth extends Model
{
    protected $connection = 'radius';
    protected $table = 'radpostauth';
}
