<?php

namespace App\Models;

class UserSubscribeLog extends Model
{
    protected $connection = 'default';
    protected $table = 'user_subscribe_log';
}
